library(rstan)
library(devtools)
library(magrittr)
try(roxygen2::roxygenize(load_code = rstantools_load_code), silent = TRUE)
roxygen2::roxygenize()
devtools::check()
devtools::build()
devtools::document()
devtools::load_all()
devtools::test()

devtools::clean_dll()
pkgbuild::compile_dll()
devtools::install()

?drive_oauth_client

googledrive::drive_auth_configure(path = "credentials.json")
googledrive::
  devtools::install_github(repo = "pedroaraujo9/tblv", subdir = "packages/btblv")

list.files("../../analysis/data/")
hmd_data = readRDS("../../analysis/data/life_tables_5x1.rds")
hmd_data = list(
  "life_tables_5x1" = readRDS("../../analysis/data/life_tables_5x1.rds"),
  "life_tables_5x5" = readRDS("../../analysis/data/life_tables_5x5.rds")
)

usethis::use_data(hmd_data, overwrite = T)


data("hmd_data")

t1 = create_btblv_data(df = hmd_data$life_tables_5x5,
                       resp_col_name = "mx",
                       item_col_name = "age",
                       group_col_name = "country",
                       time_col_name = "year")

t1$data %>% head()



lf = hmd_data$life_tables_5x5 %>%
  filter(year %in% seq(1950, 2015, 5)) %>%
  filter(!(country %in% c("East Germany", "West Germany", "New Zealand Maori",
                          "New Zealand Non-Maori", "England and Wales (Total Population)",
                          "England and Wales (Civilian Population)",
                          "Scotland", "Northern Ireland", "Wales")))


lf$country %>% unique()
btblv_data = create_btblv_data(df = lf,
                               resp_col_name = "mx",
                               item_col_name = "age",
                               group_col_name = "country",
                               time_col_name = "year")

example_fit_specific_K2 = btblv_fit(btblv_data,
                                    precision = "specific",
                                    K = 2,
                                    iter = 10,
                                    warmup = 5,
                                    thin = 1,
                                    chains = 3,
                                    cores = 3,
                                    seed = 1)

example_fit_specific_K2$stan_fit@model_pars

sm = example_fit_specific_K2$stan_fit %>% rstan::extract()
sm$

  example_fit_single_K2 = btblv_fit(btblv_data,
                                    precision = "single",
                                    K = 2,
                                    iter = 10,
                                    warmup = 5,
                                    thin = 1,
                                    chains = 2,
                                    cores = 2,
                                    seed = 1)

example_fit_single_K1 = btblv_fit(btblv_data,
                                  precision = "single",
                                  K = 1,
                                  iter = 10,
                                  warmup = 5,
                                  thin = 1,
                                  chains = 2,
                                  cores = 2,
                                  seed = 1)

example_fit_specific_K1 = btblv_fit(btblv_data,
                                    precision = "specific",
                                    K = 1,
                                    iter = 10,
                                    warmup = 5,
                                    thin = 1,
                                    chains = 3,
                                    cores = 3,
                                    seed = 1)

example_fit_specific_K2 = btblv_fit(btblv_data,
                                    precision = "specific",
                                    K = 2,
                                    iter = 10,
                                    warmup = 5,
                                    thin = 1,
                                    chains = 3,
                                    cores = 3,
                                    seed = 1)

example_fit_specific_K1$stan_fit@model_pars


post = example_fit_specific_K2 %>%
  extract_posterior()

example_fit = list(
  "single_K1" = example_fit_single_K1,
  "single_K2" = example_fit_single_K2,
  "specific_K1" = example_fit_specific_K1,
  "specific_K2" = example_fit_specific_K2
)

K = 2
btblv_data$data_list_stan$K = K
seed = 1
chains = 3
cores = chains
precision = "specific"
iter = 10
thin = 2
warmup = 5

inits = .generate_init_values(
  btblv_data = btblv_data,
  K = K,
  chains = chains,
  precision = precision,
  seed = seed
)

inits


pars = c("E", "theta", "alpha", "beta",
         "log_kappa", "baseline_delta", "delta",
         "phi", "sigma")

fit = rstan::sampling(
  object = stanmodels$time_BLV,
  data = btblv_data$data_list_stan,
  iter = iter,
  warmup = warmup,
  thin = thin,
  chains = chains,
  cores = cores,
  init = inits
)

cat(stanmodels$time_BLV@model_code)

fit@model_pars

stanmodels$time_BLV

if(precision == "single") {

  pars = c("E", "theta", "alpha", "beta", "log_kappa",
           "phi", "sigma")

  fit = rstan::sampling(
    stanmodels$time_BLV_single_precision,
    data = btblv_data$data_list_stan,
    iter = iter,
    warmup = warmup,
    thin = thin,
    chains = chains,
    cores = cores,
    init = inits,
    pars = pars,
    ...
  )

}else if(precision == "specific"){

  pars = c("E", "theta", "alpha", "beta",
           "log_kappa", "baseline_delta", "delta",
           "phi", "sigma")

  fit = rstan::sampling(
    stanmodels$time_BLV,
    data = btblv_data$data_list_stan,
    iter = iter,
    warmup = warmup,
    thin = thin,
    chains = chains,
    cores = cores,
    init = inits,
    pars = pars,
    ...
  )
}


